import UIKit

struct shifts: Decodable {
    let date: String?
    let start: String?
    let end: String?
    let shiftBreak: String?
}

class ShiftsViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    @IBOutlet var shiftCollection: UICollectionView! // Link from swift, to the collection view in storyboard
    var shiftsArray = [shifts]()  // Creating an array
    
    override func viewDidLoad() { // This will run after the storyboard has finished loading
        self.loadShiftList { success in
            if success { // If function returns success...
                DispatchQueue.main.async { // Anything inside will run in the main thread. UI Has to be changed / accessed in the main thread.
                    self.shiftCollection.reloadData() // After success of the function, it reloads the collection view.
                }
            }
            else { // If the function doesnt return success, i.e it returns an error
                print("Failed") // Prints failed in the console log
            }
        }
        super.viewDidLoad() // Makes the view visible
        shiftCollection.dataSource = self // Defines where the source of the data for the collection view is
        shiftCollection.delegate = self // Where the delegate functions
    }
    
    func loadShiftList(completion: @escaping (_ success: Bool) -> Void){ // Whens the function is run, it will return a completion, which is Boolean. Or it can be voided
        self.shiftsArray = [shifts]() // Emptying the array
        let jsonUrlString = "https://georgedevelopment.com/adam/shiftRota.php"
        guard let url = URL(string: jsonUrlString) else { return } // Ensures a valid URL is in the above variable, otherwise it returns
        URLSession.shared.dataTask(with: url) { (data, response, err) in // Takes the URL, and makes a request to it, and fetches the response into data, response & err
            guard let data = data else { return } // Ensures theres something inside of the data variable
            do { // Do the function
                let response = try JSONDecoder().decode([loadShiftsAPI].self, from: data) // Reads the json array thats sent from the api, and decodes it
                for result in response { // Loops through response arrays, making them accessable as result variable
                    let state = result.state ?? false
                    let loaded_shifts = result.all_shifts
                    if(state == true){ // If state true...
                        for item in loaded_shifts { // Loop through all shifts in the array
                            let date = item.date! // Write the date variable as the date object inside of the array
                            let start = item.shiftStarted!
                            let end = item.shiftEnded!
                            let shiftBreak = item.shift_break!
                            self.shiftsArray.append(shifts(date: date, start: start, end: end, shiftBreak: shiftBreak)) // Adds into the shifts array
                        }
                    }
                    else{ // If state is false..
                        completion(false) // Say the func has finished running, but returns false
                    }
                }
                completion(true)
            }
            catch let jsonErr { // Inside of the do... If theres an error thrown, this runs
                print("Error serializing json:", jsonErr)
                completion(false)
            }
        }.resume()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int { // Tells the collection view how many cells there is going to be
        return shiftsArray.count // The amount of arrays inside of the shiftsArray
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell { // For each cell thats being made inside the collection view, this is ran & it changes the data inside of the cell
        
        let cell = shiftCollection.dequeueReusableCell(withReuseIdentifier: "shiftCell", for: indexPath) as! ShiftCollectionViewCell // Creates a new cell, and loads it as the collectionViewCell class
        
        cell.date.text = shiftsArray[indexPath.row].date // Changes the text on the label thats called 'date' - Loads the data from the array
        cell.shiftStart.text = shiftsArray[indexPath.row].start
        cell.shiftEnd.text = shiftsArray[indexPath.row].end
        cell.break.text = shiftsArray[indexPath.row].shiftBreak! + " Break"
        
        return cell
    }
}
