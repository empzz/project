import UIKit

class TodayShiftViewController: UIViewController {
    
    @IBOutlet var shiftLabel: UILabel!
    @IBOutlet var ClockButton: UIButton!
    
    @IBAction func buttonTapped(_ sender: UIButton) { // WHen the button thats linked is pressed, run this func
        clockInOut()
    }

    override func viewDidLoad() {
        getTodaysShift() // Runs this function after the view has finished loading
        super.viewDidLoad()
    }
    
    func getTodaysShift(){
        let jsonUrlString = "https://georgedevelopment.com/adam/todaysShift.php" // This is the api url
        guard let url = URL(string: jsonUrlString) else { return } // This ensures the variable is a valid url string
        URLSession.shared.dataTask(with: url) { (data, response, err) in // This sends the request to the api url, and fetches the response
            guard let data = data else { return } // Ensures that the data variable isnt empty
            do { // Do this...
                let response = try JSONDecoder().decode([todaysShiftAPI].self, from: data) // Decodes the json array, using the todaysShiftAPI struct
                for result in response { // Loops thru all the data inside of the array
                    let state = result.state ?? false // Loads state data from the array, saves it as state variable, if result.state is empty, defaults to state = false
                    if(state == true){ // If the state variable is true
                        let shiftStatus = result.shiftStatus! // Shift status from the api
                        if(shiftStatus == "Scheduled" || shiftStatus == "Working"){ // If the shift status is Scheduled or Working...
                            let shiftStart = result.shiftStart! // Loads the data from the array, into a variable
                            let shiftFinish = result.shiftEnd! // ^^ Same
                            DispatchQueue.main.async { // Runs the following code inside of the main thread, because you have to change the UI from the main thread
                                if(shiftStatus == "Working"){ // If they have already clocked in...
                                    self.ClockButton.setTitle("Clock Out", for: .normal) // Changes the text on the button
                                }
                                self.shiftLabel.text = "\(shiftStart) - \(shiftFinish)" // Changes the text of the label
                            }
                        }
                        else{ // If shift status isnt scheduled or working...
                            DispatchQueue.main.async{ // Runs the following code inside of the main thread
                                self.shiftLabel.text = shiftStatus // Changes the UI on the storyboard to the shift status
                                self.ClockButton.isHidden = true // Hides the button as its needed.
                            }
                        }
                    }
                }
            }
            catch let jsonErr { // If theres an error in the api call, run this...
                print("Error serializing json:", jsonErr)
            }
        }.resume()
    }
    
    func clockInOut(){ // Function for the clock in / clock out button is pressed
        let jsonUrlString = "https://georgedevelopment.com/adam/clockInOut.php" // API URL
        guard let url = URL(string: jsonUrlString) else { return } // Ensures a valid url
        URLSession.shared.dataTask(with: url) { (data, response, err) in // Sends a request to the api url
            guard let data = data else { return } // Ensures the data variable isnt empty
            do { // Do the following...
                let response = try JSONDecoder().decode([clockInOutAPI].self, from: data) // Decodes the json array using the clockInOutAPI struct
                for result in response { // Loops thru the array responses
                    let state = result.state ?? false // Defines the state variable as the state data from the array, if its empty, defaults to false
                    if(state == true){ // if state variable is true...
                        let msg = result.msg! // If result.msg is empty, throws an error, if its not empty, it defines msg variable as result.msg data
                        print(msg) // Print to the console log the msg
                        self.getTodaysShift() // Runs the getTodaysShift function
                    }
                    else{ // If the state variable is false...
                        let msg = result.msg!
                        print(msg)
                    }
                }
            }
            catch let jsonErr { // If theres an error thrown
                print("Error serializing json:", jsonErr)
            }
        }.resume()
    }

}
