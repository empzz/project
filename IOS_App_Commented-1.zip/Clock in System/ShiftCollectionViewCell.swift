import UIKit

class ShiftCollectionViewCell: UICollectionViewCell {
    @IBOutlet var date: UILabel!
    @IBOutlet var shiftStart: UILabel!
    @IBOutlet var shiftEnd: UILabel!
    @IBOutlet var `break`: UILabel!
}
