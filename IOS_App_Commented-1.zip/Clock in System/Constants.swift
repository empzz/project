import Foundation

struct loadShiftsAPI: Decodable {
    let state: Bool?
    let all_shifts: [loadedShiftsAPI]
}
struct loadedShiftsAPI: Decodable {
    let date: String?
    let shiftStarted: String?
    let shiftEnded: String?
    let hoursWorked: Int?
    let shift_break: String?
}

struct loadPreviousShiftsAPI: Decodable {
    let state: Bool?
    let all_shifts: [loadedPreviousShiftsAPI]
}
struct loadedPreviousShiftsAPI: Decodable {
    let date: String?
    let shiftStarted: String?
    let shiftEnded: String?
    let hoursWorked: String?
    let shift_break: String?
    let shift_earnings: String?
}

struct todaysShiftAPI: Decodable {
    let state: Bool?
    let date: String?
    let shiftStart: String?
    let shiftEnd: String?
    let shiftBreak: String?
    let shiftStatus: String?
}

struct clockInOutAPI: Decodable {
    let state: Bool?
    let msg: String?
}

struct Constants {
    
    static let API_HOST: String = "https://georgedevelopment.com/adam"
    
    struct API_URLs {
        static let SHIFT_ROTAS: String = "\(API_HOST)/shiftRota.php"
        static let PREVIOUS_SHIFT_ROTAS: String = "\(API_HOST)/previousShifts.php"
    }
}
