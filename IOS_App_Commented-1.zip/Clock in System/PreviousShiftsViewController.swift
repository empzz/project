import UIKit

struct previousShifts: Decodable {
    let date: String?
    let hoursWorked: String?
    let shiftEarnings: String?
    let shiftBreak: String?
}

class PreviousShiftsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet var shiftCollection: UICollectionView! 
    var shiftsArray = [previousShifts]()
    
    override func viewDidLoad() {
        self.loadShiftList { success in
            if success {
                DispatchQueue.main.async { [self] in
                    shiftCollection.reloadData()
                }
            }
            else {
                print("Failed")
            }
        }
        super.viewDidLoad()
        shiftCollection.dataSource = self
        shiftCollection.delegate = self
    }
    
    func loadShiftList(completion: @escaping (_ success: Bool) -> Void){
        self.shiftsArray = [previousShifts]()
        let jsonUrlString = "https://georgedevelopment.com/adam/previousShifts.php"
        guard let url = URL(string: jsonUrlString) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            guard let data = data else { return }
            do {
                let response = try JSONDecoder().decode([loadPreviousShiftsAPI].self, from: data)
                for result in response {
                    let state = result.state ?? false
                    let loaded_shifts = result.all_shifts
                    if(state == true){
                        for item in loaded_shifts {
                            let date = item.date!
                            let hoursWorked = item.hoursWorked!
                            let shiftEarnings = item.shift_earnings!
                            let shiftBreak = item.shift_break!
                            self.shiftsArray.append(previousShifts(date: date, hoursWorked: hoursWorked, shiftEarnings: shiftEarnings, shiftBreak: shiftBreak))
                        }
                    }
                    else{
                        completion(false)
                    }
                }
                completion(true)
            }
            catch let jsonErr {
                print("Error serializing json:", jsonErr)
                completion(false)
            }
        }.resume()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shiftsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = shiftCollection.dequeueReusableCell(withReuseIdentifier: "shiftCell", for: indexPath) as! ShiftCollectionViewCell
        
        
        cell.date.text = shiftsArray[indexPath.row].date
        cell.shiftStart.text = shiftsArray[indexPath.row].hoursWorked
        cell.shiftEnd.text = "£\(shiftsArray[indexPath.row].shiftEarnings ?? "0")"
        cell.break.text = "\(shiftsArray[indexPath.row].shiftBreak ?? "00:00") Break"
        
        return cell
    }
}
